using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Views;

namespace PrintSupportApp;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        ContentFrame.Navigate(typeof(DashboardPage));
    }

    private void Navigation_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        if (args.SelectedItemContainer?.Tag is not string tag) return;
        ContentFrame.Navigate(tag switch
        {
            "printers" => typeof(PrintersPage),
            "queues" => typeof(QueuesPage),
            "jobs" => typeof(JobsPage),
            "secure" => typeof(SecurePrintPage),
            "windowsprint" => typeof(WindowsPrintPage),
            "settings" => typeof(SettingsPage),
            _ => typeof(DashboardPage)
        });
    }
}
