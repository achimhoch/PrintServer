using Microsoft.Extensions.DependencyInjection;
using Microsoft.UI.Xaml;
using PrintSupportApp.Services;

namespace PrintSupportApp;

public partial class App : Application
{
    public static IServiceProvider Services { get; private set; } = null!;
    private Window? _window;

    public App()
    {
        InitializeComponent();
        var services = new ServiceCollection();
        services.AddSingleton<ConfigurationService>();
        services.AddSingleton<PrintServerClient>();
        services.AddSingleton<PrinterService>();
        services.AddSingleton<QueueService>();
        services.AddSingleton<JobService>();
        services.AddSingleton<SocketService>();
        Services = services.BuildServiceProvider();
    }

    protected override async void OnLaunched(LaunchActivatedEventArgs args)
    {
        await Services.GetRequiredService<PrintServerClient>().InitializeAsync();
        _window = new MainWindow();
        _window.Activate();
    }
}
