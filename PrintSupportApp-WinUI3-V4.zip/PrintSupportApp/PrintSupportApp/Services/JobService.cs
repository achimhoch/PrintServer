using PrintSupportApp.Models;

namespace PrintSupportApp.Services;

public sealed class JobService(PrintServerClient client)
{
    public async Task<IReadOnlyList<PrintJob>> GetAllAsync(CancellationToken ct = default) =>
        await client.GetAsync<List<PrintJob>>("/api/jobs", ct) ?? [];

    public Task CancelAsync(long id, CancellationToken ct = default) =>
        client.DeleteAsync($"/api/jobs/{id}", ct);

    public Task<PrintJob?> SubmitSecureAsync(
        SecurePrintRequest request,
        CancellationToken ct = default) =>
        client.PostAsync<PrintJob>("/api/jobs/secure", request, ct);
}
