using System.Text.Json;
using PrintSupportApp.Models;

namespace PrintSupportApp.Services;

public sealed class ConfigurationService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    private readonly string _directory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "PrintSupportApp");

    public string ConfigurationFile => Path.Combine(_directory, "config.json");

    public async Task<AppConfiguration> LoadAsync(CancellationToken ct = default)
    {
        Directory.CreateDirectory(_directory);
        if (!File.Exists(ConfigurationFile))
            await SeedDefaultAsync(ct);

        try
        {
            await using var stream = File.OpenRead(ConfigurationFile);
            return await JsonSerializer.DeserializeAsync<AppConfiguration>(stream, JsonOptions, ct)
                   ?? new AppConfiguration();
        }
        catch
        {
            return new AppConfiguration();
        }
    }

    public async Task SaveAsync(AppConfiguration configuration, CancellationToken ct = default)
    {
        Directory.CreateDirectory(_directory);
        await using var stream = File.Create(ConfigurationFile);
        await JsonSerializer.SerializeAsync(stream, configuration, JsonOptions, ct);
    }

    private async Task SeedDefaultAsync(CancellationToken ct)
    {
        var packaged = Path.Combine(AppContext.BaseDirectory, "Config", "printserver.json");
        if (File.Exists(packaged))
        {
            File.Copy(packaged, ConfigurationFile, overwrite: true);
            return;
        }
        await SaveAsync(new AppConfiguration(), ct);
    }
}
