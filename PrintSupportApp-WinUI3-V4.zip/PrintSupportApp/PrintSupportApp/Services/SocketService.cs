using SocketIOClient;
namespace PrintSupportApp.Services;
public sealed class SocketService : IAsyncDisposable
{
    private SocketIO? _socket;
    public event EventHandler<string>? EventReceived;
    public async Task ConnectAsync(string url)
    {
        _socket = new SocketIO(url);
        _socket.OnAny((name, response) => EventReceived?.Invoke(this, name));
        await _socket.ConnectAsync();
    }
    public async ValueTask DisposeAsync() { if (_socket is not null) await _socket.DisconnectAsync(); }
}
