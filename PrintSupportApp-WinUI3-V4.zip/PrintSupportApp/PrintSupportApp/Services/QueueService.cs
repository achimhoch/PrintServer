using PrintSupportApp.Models;
namespace PrintSupportApp.Services;
public sealed class QueueService(PrintServerClient client)
{
    public async Task<IReadOnlyList<PrintQueue>> GetAllAsync(CancellationToken ct = default) =>
        await client.GetAsync<List<PrintQueue>>("/api/queues", ct) ?? [];
}
