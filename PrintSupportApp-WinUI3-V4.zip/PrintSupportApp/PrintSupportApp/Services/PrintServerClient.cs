using System.Net.Http.Json;
using PrintSupportApp.Models;

namespace PrintSupportApp.Services;

public sealed class PrintServerClient
{
    private readonly HttpClient _client = new() { Timeout = TimeSpan.FromSeconds(30) };
    private readonly ConfigurationService _configurationService;
    private AppConfiguration _configuration = new();

    public PrintServerClient(ConfigurationService configurationService)
    {
        _configurationService = configurationService;
    }

    public AppConfiguration Configuration => _configuration;

    public async Task InitializeAsync(CancellationToken ct = default)
    {
        _configuration = await _configurationService.LoadAsync(ct);
        ApplyConfiguration(_configuration);
    }

    public async Task UpdateConfigurationAsync(AppConfiguration configuration, CancellationToken ct = default)
    {
        await _configurationService.SaveAsync(configuration, ct);
        _configuration = configuration;
        ApplyConfiguration(configuration);
    }

    private void ApplyConfiguration(AppConfiguration configuration)
    {
        var url = configuration.ServerUrl.Trim();
        if (!url.EndsWith('/')) url += "/";
        _client.BaseAddress = new Uri(url, UriKind.Absolute);
        _client.DefaultRequestHeaders.Remove("X-API-Key");
        if (!string.IsNullOrWhiteSpace(configuration.ApiKey))
            _client.DefaultRequestHeaders.TryAddWithoutValidation("X-API-Key", configuration.ApiKey);
    }

    public async Task<T?> GetAsync<T>(string uri, CancellationToken ct = default)
    {
        using var response = await _client.GetAsync(uri, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct);
    }

    public async Task<T?> PostAsync<T>(string uri, object body, CancellationToken ct = default)
    {
        using var response = await _client.PostAsJsonAsync(uri, body, ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct);
    }

    public async Task DeleteAsync(string uri, CancellationToken ct = default)
    {
        using var response = await _client.DeleteAsync(uri, ct);
        response.EnsureSuccessStatusCode();
    }

    public async Task<bool> PingAsync(CancellationToken ct = default)
    {
        try
        {
            using var response = await _client.GetAsync("api/printer", ct);
            return response.IsSuccessStatusCode;
        }
        catch { return false; }
    }
}
