using PrintSupportApp.Models;
namespace PrintSupportApp.Services;
public sealed class PrinterService(PrintServerClient client)
{
    public async Task<IReadOnlyList<Printer>> GetAllAsync(CancellationToken ct = default) =>
        await client.GetAsync<List<Printer>>("/api/printer", ct) ?? [];
}
