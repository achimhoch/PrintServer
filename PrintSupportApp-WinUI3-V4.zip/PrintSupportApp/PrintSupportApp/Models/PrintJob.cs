namespace PrintSupportApp.Models;
public sealed class PrintJob
{
    public long Id { get; set; }
    public long? PrinterId { get; set; }
    public long? QueueId { get; set; }
    public string? Name { get; set; }
    public string? Status { get; set; }
    public int Progress { get; set; }
}
