namespace PrintSupportApp.Models;
public sealed class Printer
{
    public long Id { get; set; }
    public string? Uuid { get; set; }
    public string? Name { get; set; }
    public string? Hostname { get; set; }
    public string? Ip { get; set; }
    public string? Uri { get; set; }
    public string? Protocol { get; set; }
    public string? Manufacturer { get; set; }
    public string? Model { get; set; }
    public string? Location { get; set; }
    public string? State { get; set; }
    public bool Online { get; set; }
}
