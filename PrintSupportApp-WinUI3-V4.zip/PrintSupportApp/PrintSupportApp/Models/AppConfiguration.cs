namespace PrintSupportApp.Models;

public sealed class AppConfiguration
{
    public string ServerUrl { get; set; } = "http://localhost:3000";
    public string ApiKey { get; set; } = "";
    public long QueueId { get; set; } = 1;
    public string SecurePin { get; set; } = "";
}
