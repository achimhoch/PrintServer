namespace PrintSupportApp.Models;

public sealed class SecurePrintRequest
{
    public long QueueId { get; set; }
    public string FileName { get; set; } = "";
    public string FilePath { get; set; } = "";
    public string Pin { get; set; } = "";
}
