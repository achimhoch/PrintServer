namespace PrintSupportApp.Models;
public sealed class PrintQueue
{
    public long Id { get; set; }
    public string? Name { get; set; }
    public long PrinterId { get; set; }
    public bool Enabled { get; set; }
}
