using Microsoft.UI.Xaml.Controls;
namespace PrintSupportApp.Views;
public sealed partial class WindowsPrintPage : Page
{
    public WindowsPrintPage() => InitializeComponent();
}
