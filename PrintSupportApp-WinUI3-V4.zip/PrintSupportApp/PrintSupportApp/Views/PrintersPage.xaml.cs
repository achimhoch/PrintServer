using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Services;
namespace PrintSupportApp.Views;
public sealed partial class PrintersPage : Page
{
    readonly PrinterService service = App.Services.GetRequiredService<PrinterService>();
    public PrintersPage() { InitializeComponent(); Loaded += async (_, _) => await LoadAsync(); }
    async Task LoadAsync() { try { PrinterList.ItemsSource = await service.GetAllAsync(); } catch (Exception ex) { PrinterList.ItemsSource = new[] { new { Name = "Fehler", Ip = "", State = ex.Message } }; } }
    private async void Refresh_Click(object sender, RoutedEventArgs e) => await LoadAsync();
}
