using Microsoft.UI.Xaml.Controls;
namespace PrintSupportApp.Views;
public sealed partial class DashboardPage : Page { public DashboardPage() => InitializeComponent(); }
