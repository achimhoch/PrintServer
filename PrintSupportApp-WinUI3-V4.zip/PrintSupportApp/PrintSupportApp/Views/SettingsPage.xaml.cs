using Microsoft.Extensions.DependencyInjection;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Models;
using PrintSupportApp.Services;

namespace PrintSupportApp.Views;

public sealed partial class SettingsPage : Page
{
    private readonly PrintServerClient _client = App.Services.GetRequiredService<PrintServerClient>();
    private readonly ConfigurationService _configuration = App.Services.GetRequiredService<ConfigurationService>();

    public SettingsPage()
    {
        InitializeComponent();
        Loaded += SettingsPage_Loaded;
    }

    private async void SettingsPage_Loaded(object sender, RoutedEventArgs e)
    {
        var config = await _configuration.LoadAsync();
        Server.Text = config.ServerUrl;
        Key.Password = config.ApiKey;
        QueueId.Value = config.QueueId;
        SecurePin.Password = config.SecurePin;
        ConfigPath.Text = "Konfigurationsdatei: " + _configuration.ConfigurationFile;
    }

    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        if (!Uri.TryCreate(Server.Text, UriKind.Absolute, out _))
        {
            Show("Fehler", "Ungültige ServerUrl.", InfoBarSeverity.Error);
            return;
        }

        var config = new AppConfiguration
        {
            ServerUrl = Server.Text.Trim(),
            ApiKey = Key.Password,
            QueueId = Math.Max(1, (long)QueueId.Value),
            SecurePin = SecurePin.Password
        };

        await _client.UpdateConfigurationAsync(config);
        var ok = await _client.PingAsync();
        Show(ok ? "Gespeichert" : "Gespeichert – Server nicht erreichbar",
             ok ? "ServerUrl und API-Key wurden gespeichert; der Printserver antwortet." :
                  "Die Konfiguration wurde gespeichert, der Printserver antwortet jedoch nicht.",
             ok ? InfoBarSeverity.Success : InfoBarSeverity.Warning);
    }

    private void Show(string title, string message, InfoBarSeverity severity)
    {
        Info.Title = title; Info.Message = message; Info.Severity = severity; Info.IsOpen = true;
    }
}
