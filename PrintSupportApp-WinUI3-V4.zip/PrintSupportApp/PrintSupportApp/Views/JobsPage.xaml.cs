using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Services;
namespace PrintSupportApp.Views;
public sealed partial class JobsPage : Page
{
 readonly JobService service=App.Services.GetRequiredService<JobService>();
 public JobsPage(){InitializeComponent();Loaded+=async(_,_)=>await LoadAsync();}
 async Task LoadAsync(){try{JobList.ItemsSource=await service.GetAllAsync();}catch(Exception ex){JobList.ItemsSource=new[]{new{ Name="Fehler: "+ex.Message, Status="", Progress=0 }};}}
 private async void Refresh_Click(object sender,RoutedEventArgs e)=>await LoadAsync();
}
