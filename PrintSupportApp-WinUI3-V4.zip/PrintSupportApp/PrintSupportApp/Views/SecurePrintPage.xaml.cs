using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Models;
using PrintSupportApp.Services;

namespace PrintSupportApp.Views;

public sealed partial class SecurePrintPage : Page
{
    private readonly JobService _jobs = App.Services.GetRequiredService<JobService>();

    public SecurePrintPage() => InitializeComponent();

    private async void Submit_Click(object sender, RoutedEventArgs e)
    {
        if (!long.TryParse(QueueId.Text, out var queueId))
        {
            Show("Fehler", "Ungültige Queue-ID.", InfoBarSeverity.Error);
            return;
        }

        if (string.IsNullOrWhiteSpace(FilePath.Text) ||
            string.IsNullOrWhiteSpace(Pin.Password))
        {
            Show("Fehler", "Dateipfad und PIN müssen angegeben werden.",
                InfoBarSeverity.Error);
            return;
        }

        try
        {
            await _jobs.SubmitSecureAsync(new SecurePrintRequest
            {
                QueueId = queueId,
                FileName = FileName.Text,
                FilePath = FilePath.Text,
                Pin = Pin.Password
            });

            Show("Gesendet",
                "Der Secure-Print-Auftrag wurde an den Printserver übertragen.",
                InfoBarSeverity.Success);
        }
        catch (Exception ex)
        {
            Show("Fehler", ex.Message, InfoBarSeverity.Error);
        }
    }

    private void Show(string title, string message, InfoBarSeverity severity)
    {
        Info.Title = title;
        Info.Message = message;
        Info.Severity = severity;
        Info.IsOpen = true;
    }
}
