using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using PrintSupportApp.Services;
namespace PrintSupportApp.Views;
public sealed partial class QueuesPage : Page
{
 readonly QueueService service=App.Services.GetRequiredService<QueueService>();
 public QueuesPage(){InitializeComponent();Loaded+=async(_,_)=>await LoadAsync();}
 async Task LoadAsync(){try{QueueList.ItemsSource=await service.GetAllAsync();}catch(Exception ex){QueueList.ItemsSource=new[]{new{ Name="Fehler: "+ex.Message }};}}
 private async void Refresh_Click(object sender,RoutedEventArgs e)=>await LoadAsync();
}
