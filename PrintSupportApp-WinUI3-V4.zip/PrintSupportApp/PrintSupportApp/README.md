Siehe ../README.md für die V4-Gesamtdokumentation.
