param(
    [ValidateSet("Debug","Release")][string]$Configuration = "Debug",
    [ValidateSet("x64")][string]$Platform = "x64"
)
$ErrorActionPreference = "Stop"
$root = Resolve-Path "$PSScriptRoot\.."
& "$PSScriptRoot\Sync-Configuration.ps1"
Push-Location $root
try {
    msbuild .\PrintSupportApp.sln /restore /m /p:Configuration=$Configuration /p:Platform=$Platform
} finally { Pop-Location }
