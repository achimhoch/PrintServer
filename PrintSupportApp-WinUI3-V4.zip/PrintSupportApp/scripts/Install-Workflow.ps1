$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$packageRoot = Join-Path $root "PrintSupportWorkflow\AppPackages"
$install = Get-ChildItem -Path $packageRoot -Filter "Add-AppDevPackage.ps1" -Recurse | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $install) { throw "No AppPackages/Add-AppDevPackage.ps1 found. Create an App Package from Visual Studio first." }
& $install.FullName
