param(
    [string]$Source = "$PSScriptRoot\..\Config\printserver.json"
)
$ErrorActionPreference = "Stop"
$root = (Resolve-Path "$PSScriptRoot\..").Path
$sourcePath = (Resolve-Path $Source).Path
$targets = @(
    (Join-Path $root "PrintSupportApp\Config\printserver.json")
    (Join-Path $root "PrintSupportWorkflow\Config\printserver.json")
)
foreach ($target in $targets) {
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
    Copy-Item -Path $sourcePath -Destination $target -Force
    Write-Host "Config -> $target"
}
