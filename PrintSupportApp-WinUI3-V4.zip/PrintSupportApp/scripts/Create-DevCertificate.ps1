$ErrorActionPreference = "Stop"
$project = Join-Path (Split-Path -Parent $PSScriptRoot) "PrintSupportWorkflow"
$pfx = Join-Path $project "PrintSupportWorkflow_TemporaryKey.pfx"
$subject = "CN=PrintSupportApp-Development"
$password = ConvertTo-SecureString "PrintSupportV4-DevOnly!" -AsPlainText -Force
$cert = New-SelfSignedCertificate -Type Custom -Subject $subject -KeyUsage DigitalSignature -FriendlyName "PrintSupportApp V4 Development" -CertStoreLocation "Cert:\CurrentUser\My" -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.3")
Export-PfxCertificate -Cert $cert -FilePath $pfx -Password $password | Out-Null
Write-Host "Created $pfx"
Write-Host "Development password: PrintSupportV4-DevOnly!"
