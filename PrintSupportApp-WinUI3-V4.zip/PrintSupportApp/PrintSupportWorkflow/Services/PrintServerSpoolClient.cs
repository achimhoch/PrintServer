using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using PrintSupportWorkflow.Models;
using Windows.Storage.Streams;

namespace PrintSupportWorkflow.Services;

public static class PrintServerSpoolClient
{
    public static async Task UploadAsync(
        PrintServerConfiguration configuration,
        IInputStream source,
        string fileName,
        string contentType)
    {
        using (var http = new HttpClient())
        {
            http.BaseAddress = new Uri(configuration.ServerUrl.TrimEnd('/') + "/");
            http.Timeout = TimeSpan.FromMinutes(10);

            if (!string.IsNullOrWhiteSpace(configuration.ApiKey))
                http.DefaultRequestHeaders.TryAddWithoutValidation("X-API-Key", configuration.ApiKey);

            using (var input = source.AsStreamForRead())
            using (var form = new MultipartFormDataContent())
            using (var content = new StreamContent(input))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
                form.Add(new StringContent(configuration.QueueId.ToString()), "queueId");
                form.Add(new StringContent(configuration.SecurePin ?? ""), "securePin");
                form.Add(new StringContent("windows-virtual-printer"), "source");
                form.Add(new StringContent(contentType), "contentType");
                form.Add(content, "document", fileName);

                using (var response = await http.PostAsync("api/jobs/spool", form))
                    response.EnsureSuccessStatusCode();
            }
        }
    }
}
