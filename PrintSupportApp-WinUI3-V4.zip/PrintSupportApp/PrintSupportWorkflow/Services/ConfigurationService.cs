using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using PrintSupportWorkflow.Models;
using Windows.Storage;

namespace PrintSupportWorkflow.Services;

public static class ConfigurationService
{
    private const string FileName = "printserver.json";

    public static async Task<PrintServerConfiguration> LoadAsync()
    {
        // First preference: writable UWP LocalFolder configuration.
        try
        {
            var local = await ApplicationData.Current.LocalFolder.TryGetItemAsync(FileName) as StorageFile;
            if (local != null)
                return await ReadAsync(local);
        }
        catch { }

        // Fallback: configuration shipped in the package.
        try
        {
            var packaged = await StorageFile.GetFileFromApplicationUriAsync(
                new Uri("ms-appx:///Config/printserver.json"));
            return await ReadAsync(packaged);
        }
        catch { return new PrintServerConfiguration(); }
    }

    private static async Task<PrintServerConfiguration> ReadAsync(StorageFile file)
    {
        var json = await FileIO.ReadTextAsync(file);
        var serializer = new DataContractJsonSerializer(typeof(PrintServerConfiguration));
        using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            return (PrintServerConfiguration)serializer.ReadObject(stream);
    }
}
