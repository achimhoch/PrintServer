using System.Runtime.Serialization;

namespace PrintSupportWorkflow.Models;

[DataContract]
public sealed class PrintServerConfiguration
{
    [DataMember] public string ServerUrl { get; set; } = "http://localhost:3000";
    [DataMember] public string ApiKey { get; set; } = "";
    [DataMember] public long QueueId { get; set; } = 1;
    [DataMember] public string SecurePin { get; set; } = "";
}
