using System;
using Windows.ApplicationModel.Background;
using Windows.Graphics.Printing.Workflow;
using PrintSupportWorkflow.Services;

namespace PrintSupportWorkflow.Tasks;

// This is the activation entry point required by the Windows Print Support
// Virtual Printer contract. It is not a continuously running background service.
public sealed class PrintSupportWorkflowBackgroundTask : IBackgroundTask
{
    private BackgroundTaskDeferral _deferral;
    private PrintWorkflowVirtualPrinterSession _session;
    private bool _completed;

    public void Run(IBackgroundTaskInstance taskInstance)
    {
        _deferral = taskInstance.GetDeferral();
        taskInstance.Canceled += OnCanceled;

        var details = taskInstance.TriggerDetails as PrintWorkflowVirtualPrinterTriggerDetails;
        if (details == null)
        {
            CompleteTask();
            return;
        }

        _session = details.VirtualPrinterSession;
        _session.VirtualPrinterDataAvailable += OnVirtualPrinterDataAvailable;
        _session.Start();
    }

    private async void OnVirtualPrinterDataAvailable(
        PrintWorkflowVirtualPrinterSession sender,
        PrintWorkflowVirtualPrinterDataAvailableEventArgs args)
    {
        var submitted = PrintWorkflowSubmittedStatus.Failed;
        try
        {
            var config = await ConfigurationService.LoadAsync();
            if (string.IsNullOrWhiteSpace(config.ServerUrl))
                throw new InvalidOperationException("ServerUrl is missing in printserver.json.");

            var source = args.SourceContent;
            var inputStream = source.GetInputStream();
            var fileName = "windows-print-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + ".oxps";

            await PrintServerSpoolClient.UploadAsync(
                config,
                inputStream,
                fileName,
                "application/oxps");

            submitted = PrintWorkflowSubmittedStatus.Succeeded;
        }
        catch
        {
            submitted = PrintWorkflowSubmittedStatus.Failed;
        }
        finally
        {
            args.CompleteJob(submitted);
            CompleteTask();
        }
    }

    private void OnCanceled(IBackgroundTaskInstance sender, BackgroundTaskCancellationReason reason)
    {
        CompleteTask();
    }

    private void CompleteTask()
    {
        if (_completed) return;
        _completed = true;
        if (_session != null)
            _session.VirtualPrinterDataAvailable -= OnVirtualPrinterDataAvailable;
        _deferral?.Complete();
    }
}
