using Windows.UI.Xaml;

namespace PrintSupportWorkflow;

// Package application host. The virtual printer itself is activated by the
// windows.printSupportVirtualPrinterWorkflow extension declared in the manifest.
sealed partial class App : Application
{
    public App() => InitializeComponent();
}
