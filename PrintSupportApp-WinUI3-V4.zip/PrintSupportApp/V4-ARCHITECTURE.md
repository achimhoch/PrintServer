# PrintSupportApp V4 – Architektur

## Komponenten

- **PrintSupportApp**: WinUI 3 Desktop-Anwendung für Drucker, Queues, Jobs, Secure Print und Konfiguration.
- **PrintSupportWorkflow**: UWP/WinRT **Print Support Virtual Printer Workflow**. Kein dauerhaft laufender UWP-Hintergrundservice.
- **PrintSupport Server**: durch das MSIX-Manifest installierter virtueller Windows-Drucker.
- **Node.js Printserver**: nimmt den Windows-Spooljob über `POST /api/jobs/spool` entgegen.

## Druckpfad

```text
Office / Browser / Windows-App
        -> Windows Print System
        -> "PrintSupport Server" Virtual Printer
        -> windows.printSupportVirtualPrinterWorkflow
        -> PrintWorkflowVirtualPrinterDataAvailable
        -> OXPS stream
        -> multipart POST /api/jobs/spool
        -> JobService / JobManager / QueueManager
        -> IPP/IPPS Driver
        -> physischer Drucker
```

## Konfiguration

Die kanonische Build-Konfiguration liegt unter `Config/printserver.json`.
`scripts/Sync-Configuration.ps1` kopiert sie in beide Projekte.

Die WinUI-App legt beim ersten Start zusätzlich eine beschreibbare Benutzerkopie unter
`%LOCALAPPDATA%\PrintSupportApp\config.json` an. Diese kann auf der Seite **Einstellungen** geändert werden.

Der UWP Virtual Printer Workflow liest zuerst `ApplicationData.Current.LocalFolder\printserver.json` und fällt anschließend auf die paketierte `Config\printserver.json` zurück.

## Windows-Anforderung

Der Manifestvertrag `windows.printSupportVirtualPrinterWorkflow` und die verwendeten Virtual-Printer-APIs erfordern Windows 11 24H2 / Build 26100 oder neuer.
