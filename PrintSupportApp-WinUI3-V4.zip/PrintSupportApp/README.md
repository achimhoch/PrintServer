# PrintSupportApp WinUI 3 – V4

V4 trennt die Verwaltungsoberfläche und den Windows-Druckpfad sauber:

- `PrintSupportApp/` – WinUI 3 Desktop Client
- `PrintSupportWorkflow/` – UWP Print Support **Virtual Printer Workflow**
- `Config/printserver.json` – zentrale Build-Konfiguration
- `server-example/` – Beispielroute für `POST /api/jobs/spool`
- `scripts/` – Konfigurations-Sync, Build, Zertifikat und Installation

## Zentrale Konfiguration

```json
{
  "ServerUrl": "http://localhost:3000",
  "ApiKey": "",
  "QueueId": 1,
  "SecurePin": ""
}
```

Vor einem Build:

```powershell
.\scripts\Sync-Configuration.ps1
```

Oder direkt:

```powershell
.\scripts\Build-V4.ps1 -Configuration Debug -Platform x64
```

## Virtual Printer

`PrintSupportWorkflow/Package.appxmanifest` registriert ausschließlich den Vertrag
`windows.printSupportVirtualPrinterWorkflow`. Der installierte Drucker heißt **PrintSupport Server**.
Windows erzeugt `application/oxps` und aktiviert `PrintSupportWorkflowBackgroundTask` nur für den Druckworkflow.
Es gibt keine normale UWP `MainPage` und keine allgemeine `windows.printSupportExtension`-Background-Extension mehr.

## Printserver API

Der Workflow sendet Multipart-Formdata an:

`POST /api/jobs/spool`

Felder: `queueId`, `securePin`, `source`, `contentType`, `document`.

## Voraussetzungen

- Windows 11 24H2 / Build 26100 oder neuer
- Visual Studio 2022
- Windows 11 SDK 10.0.26100.0
- UWP Development Workload
- .NET 8 + Windows App SDK für `PrintSupportApp`

Siehe `V4-ARCHITECTURE.md` für den vollständigen Ablauf.
