"use strict";

// Example Express route for PrintSupportApp V4.
// Adapt repository/service names to the actual Printserver project.
const express = require("express");
const multer = require("multer");
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 250 * 1024 * 1024 } });

module.exports = function createSpoolRouter({ jobService }) {
    const router = express.Router();

    router.post("/spool", upload.single("document"), async (req, res, next) => {
        try {
            if (!req.file) return res.status(400).json({ error: "document is required" });
            const queueId = Number(req.body.queueId);
            if (!Number.isInteger(queueId) || queueId <= 0)
                return res.status(400).json({ error: "valid queueId is required" });

            const job = await jobService.add({
                queueId,
                name: req.file.originalname,
                source: req.body.source || "windows-virtual-printer",
                mimeType: req.body.contentType || req.file.mimetype,
                securePin: req.body.securePin || null,
                data: req.file.buffer
            });

            res.status(201).json(job);
        } catch (err) {
            next(err);
        }
    });

    return router;
};
